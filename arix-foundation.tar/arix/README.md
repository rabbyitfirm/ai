# ARIX.ai — Your Intelligent AI Workspace

Production-grade, multi-tenant AI SaaS platform. This repository is the
**runnable MVP foundation** — the architectural spine that the full feature set
(per the SRS) is built on, module by module.

> Scope note: the complete platform is, by the SRS's own estimate, a 6–12 month
> build (150–250 tables, 500+ endpoints). This foundation is the ~8–12 week MVP
> core: monorepo, full data model, the model-router/Custom-Models layer, and a
> streaming chat path you can run today.

## What's here now

```
arix/
├── apps/
│   ├── api/                  # NestJS backend
│   │   └── src/
│   │       ├── llm/          # ⭐ Model router + provider adapters (core IP)
│   │       │   ├── llm-provider.interface.ts
│   │       │   ├── model-router.service.ts
│   │       │   └── providers/
│   │       │       ├── openai-compat.provider.ts  # OpenAI + ALL custom/self-hosted
│   │       │       └── anthropic.provider.ts
│   │       ├── chat/         # SSE streaming chat endpoint
│   │       └── database/     # PrismaService
│   └── web/                  # Next.js 15 frontend (skeleton — next session)
├── packages/
│   └── database/             # Prisma schema, seed, client
│       └── prisma/schema.prisma   # ⭐ Full multi-tenant data model
├── infra/docker/             # Postgres, Redis, Qdrant, MinIO
└── .github/workflows/        # CI
```

## The model router (Custom Models)

Business logic never talks to a vendor SDK. It calls `ModelRouterService`,
which: resolves the tenant's enabled providers, instantiates the right adapter,
runs a **fallback chain**, honors a `privacyOnly` flag (self-hosted only), and
records token usage for billing.

Adding a **custom / self-hosted model** is config, not code: create a
`ModelProvider` row with `kind = CUSTOM`, a `baseUrl` pointing at any
OpenAI-compatible endpoint (vLLM, Ollama, LM Studio, Together, Groq…), and a
model name. The same `OpenAiCompatProvider` adapter handles it.

## Quickstart

```bash
# 1. Boot infrastructure
cp .env.example .env
npm install
npm run docker:up            # Postgres, Redis, Qdrant, MinIO

# 2. Database
npm run db:generate          # needs network access to binaries.prisma.sh
npm run db:migrate
npm run db:seed              # creates admin@arix.ai / demo@arix.ai

# 3. Run the API
npm run dev -w @arix/api     # http://localhost:3001/api
```

### Try the streaming chat (after setting OPENAI_API_KEY and seeding)

```bash
curl -N http://localhost:3001/api/chat/stream \
  -H 'Content-Type: application/json' \
  -d '{"organizationId":"<demo-org-id>","messages":[{"role":"user","content":"Hello"}]}'
```

## Verified in this build

- `apps/api/src/llm/*` (interface + both provider adapters) **type-checks
  cleanly under `tsc --strict`**.
- Prisma schema is written and self-consistent; `prisma validate` /
  `generate` require downloading the Prisma engine (blocked in the authoring
  sandbox) — run them locally.

## Build sequence (next sessions)

2. Auth + multi-tenancy guards · 3. RAG/knowledge ingestion (Qdrant) ·
4. Agents + tool calling · 5. Workflow engine (BullMQ) · 6. Stripe billing ·
7. Admin panel · 8. Next.js dashboard UI.
