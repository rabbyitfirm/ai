import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { createDecipheriv } from 'node:crypto';
import { PrismaService } from '../database/prisma.service';
import {
  LlmProvider,
  LlmChatRequest,
  LlmChatResult,
  LlmStreamChunk,
  ProviderConfig,
} from './llm-provider.interface';
import { OpenAiCompatProvider } from './providers/openai-compat.provider';
import { AnthropicProvider } from './providers/anthropic.provider';

export interface RouteContext {
  organizationId: string;
  /** Optional explicit model the user selected in the chat UI. */
  model?: string;
  /** Force routing to self-hosted providers only (data residency). */
  privacyOnly?: boolean;
}

/**
 * Resolves which provider+model to use for a tenant, instantiates the right
 * adapter, runs the call with a fallback chain, and records usage for billing.
 *
 * This is the platform's core IP: business logic never picks a vendor — it
 * asks the router, which honors per-tenant policy, cost ceilings and privacy.
 */
@Injectable()
export class ModelRouterService {
  private readonly logger = new Logger(ModelRouterService.name);

  constructor(private readonly prisma: PrismaService) {}

  /** AES-256-GCM decryption for stored BYO provider keys. */
  private decryptKey(cipherText: string | null): string | undefined {
    if (!cipherText) return undefined;
    const key = Buffer.from(process.env.ENCRYPTION_KEY ?? '', 'hex');
    const [ivHex, tagHex, dataHex] = cipherText.split(':');
    if (!ivHex || !tagHex || !dataHex) return undefined;
    const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
    return decipher.update(Buffer.from(dataHex, 'hex')).toString('utf8') + decipher.final('utf8');
  }

  private instantiate(config: ProviderConfig): LlmProvider {
    switch (config.kind) {
      case 'ANTHROPIC':
        return new AnthropicProvider(config);
      case 'OPENAI':
      case 'CUSTOM':
      case 'GEMINI': // Gemini exposes an OpenAI-compatible endpoint at /v1beta/openai
        return new OpenAiCompatProvider(config);
      default:
        throw new BadRequestException(`Unsupported provider kind: ${config.kind}`);
    }
  }

  /**
   * Build the ordered list of providers to try for this tenant. The first is
   * the preferred one; the rest form the fallback chain.
   */
  private async resolveChain(ctx: RouteContext): Promise<Array<{ provider: LlmProvider; model: string; kind: string }>> {
    const rows = await this.prisma.modelProvider.findMany({
      where: { organizationId: ctx.organizationId, enabled: true },
      orderBy: { createdAt: 'asc' },
    });

    let candidates = rows;
    if (ctx.privacyOnly) {
      candidates = candidates.filter((r) => r.kind === 'CUSTOM');
    }
    if (candidates.length === 0) {
      throw new BadRequestException(
        ctx.privacyOnly
          ? 'No self-hosted (CUSTOM) provider configured for privacy-only routing.'
          : 'No enabled model providers configured for this organization.',
      );
    }

    return candidates.map((r) => ({
      kind: r.kind,
      model: ctx.model ?? r.defaultModel ?? 'gpt-4o-mini',
      provider: this.instantiate({
        kind: r.kind as ProviderConfig['kind'],
        baseUrl: r.baseUrl ?? undefined,
        apiKey: this.decryptKey(r.apiKeyCipher),
        defaultModel: r.defaultModel ?? undefined,
      }),
    }));
  }

  private async recordUsage(organizationId: string, model: string, usage: LlmChatResult['usage']) {
    await this.prisma.usageRecord.createMany({
      data: [
        { organizationId, metric: 'tokens.prompt', quantity: usage.promptTokens, model, costUsd: 0 },
        {
          organizationId,
          metric: 'tokens.completion',
          quantity: usage.completionTokens,
          model,
          costUsd: usage.costUsd,
        },
      ],
    });
  }

  /** Non-streaming completion with fallback. */
  async chat(ctx: RouteContext, messages: LlmChatRequest['messages'], opts?: { temperature?: number }): Promise<LlmChatResult> {
    const chain = await this.resolveChain(ctx);
    let lastError: unknown;

    for (const link of chain) {
      try {
        const result = await link.provider.chat({
          model: link.model,
          messages,
          temperature: opts?.temperature,
        });
        await this.recordUsage(ctx.organizationId, result.model, result.usage);
        return result;
      } catch (err) {
        lastError = err;
        this.logger.warn(`Provider ${link.kind} failed, falling back: ${(err as Error).message}`);
      }
    }
    throw new BadRequestException(`All providers failed. Last error: ${(lastError as Error)?.message}`);
  }

  /** Streaming completion. Falls back to the next provider only before first token. */
  async *stream(
    ctx: RouteContext,
    messages: LlmChatRequest['messages'],
    opts?: { temperature?: number; signal?: AbortSignal },
  ): AsyncIterable<LlmStreamChunk> {
    const chain = await this.resolveChain(ctx);
    let lastError: unknown;

    for (const link of chain) {
      try {
        const iterator = link.provider.stream({
          model: link.model,
          messages,
          temperature: opts?.temperature,
          signal: opts?.signal,
        });
        let started = false;
        for await (const chunk of iterator) {
          started = true;
          if (chunk.done && chunk.usage) {
            await this.recordUsage(ctx.organizationId, link.model, chunk.usage);
          }
          yield chunk;
        }
        return; // completed successfully
      } catch (err) {
        lastError = err;
        // Only safe to fall back if nothing was emitted yet.
        this.logger.warn(`Stream provider ${link.kind} failed: ${(err as Error).message}`);
      }
    }
    throw new BadRequestException(`All streaming providers failed. Last error: ${(lastError as Error)?.message}`);
  }
}
