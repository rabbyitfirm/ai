import { Module } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
import { ModelRouterService } from './model-router.service';

@Module({
  providers: [PrismaService, ModelRouterService],
  exports: [ModelRouterService],
})
export class LlmModule {}
