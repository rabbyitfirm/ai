import {
  LlmProvider,
  LlmChatRequest,
  LlmChatResult,
  LlmStreamChunk,
  ProviderConfig,
} from '../llm-provider.interface';

/**
 * Anthropic Messages API adapter. Differs from OpenAI in two ways the adapter
 * normalizes: (1) the system prompt is a top-level field, not a message;
 * (2) the streaming event shape uses typed events.
 */
export class AnthropicProvider implements LlmProvider {
  readonly kind = 'ANTHROPIC' as const;
  private readonly baseUrl: string;
  private readonly apiKey: string;

  private static readonly PRICING: Record<string, { in: number; out: number }> = {
    'claude-3-5-sonnet-latest': { in: 3, out: 15 },
    'claude-3-5-haiku-latest': { in: 0.8, out: 4 },
  };

  constructor(config: ProviderConfig) {
    this.baseUrl = (config.baseUrl ?? 'https://api.anthropic.com/v1').replace(/\/$/, '');
    this.apiKey = config.apiKey ?? '';
  }

  private headers(): Record<string, string> {
    return {
      'Content-Type': 'application/json',
      'x-api-key': this.apiKey,
      'anthropic-version': '2023-06-01',
    };
  }

  /** Split a uniform message list into Anthropic's system + messages shape. */
  private split(req: LlmChatRequest) {
    const system = req.messages
      .filter((m) => m.role === 'system')
      .map((m) => m.content)
      .join('\n\n');
    const messages = req.messages
      .filter((m) => m.role === 'user' || m.role === 'assistant')
      .map((m) => ({ role: m.role, content: m.content }));
    return { system, messages };
  }

  private estimateCost(model: string, inTok: number, outTok: number): number {
    const p = AnthropicProvider.PRICING[model];
    if (!p) return 0;
    return (inTok / 1e6) * p.in + (outTok / 1e6) * p.out;
  }

  async chat(req: LlmChatRequest): Promise<LlmChatResult> {
    const { system, messages } = this.split(req);
    const res = await fetch(`${this.baseUrl}/messages`, {
      method: 'POST',
      headers: this.headers(),
      signal: req.signal,
      body: JSON.stringify({
        model: req.model,
        system: system || undefined,
        messages,
        temperature: req.temperature ?? 0.7,
        max_tokens: req.maxTokens ?? 4096,
      }),
    });
    if (!res.ok) throw new Error(`Anthropic error ${res.status}: ${await res.text()}`);

    const data: any = await res.json();
    const inTok = data.usage?.input_tokens ?? 0;
    const outTok = data.usage?.output_tokens ?? 0;
    return {
      content: (data.content ?? []).map((b: any) => b.text ?? '').join(''),
      model: data.model ?? req.model,
      usage: { promptTokens: inTok, completionTokens: outTok, costUsd: this.estimateCost(req.model, inTok, outTok) },
    };
  }

  async *stream(req: LlmChatRequest): AsyncIterable<LlmStreamChunk> {
    const { system, messages } = this.split(req);
    const res = await fetch(`${this.baseUrl}/messages`, {
      method: 'POST',
      headers: this.headers(),
      signal: req.signal,
      body: JSON.stringify({
        model: req.model,
        system: system || undefined,
        messages,
        temperature: req.temperature ?? 0.7,
        max_tokens: req.maxTokens ?? 4096,
        stream: true,
      }),
    });
    if (!res.ok || !res.body) throw new Error(`Anthropic error ${res.status}: ${await res.text()}`);

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let inTok = 0;
    let outTok = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        try {
          const json = JSON.parse(trimmed.slice(5).trim());
          if (json.type === 'message_start') inTok = json.message?.usage?.input_tokens ?? 0;
          if (json.type === 'content_block_delta' && json.delta?.text) {
            yield { delta: json.delta.text, done: false };
          }
          if (json.type === 'message_delta') outTok = json.usage?.output_tokens ?? outTok;
          if (json.type === 'message_stop') {
            yield {
              delta: '',
              done: true,
              usage: { promptTokens: inTok, completionTokens: outTok, costUsd: this.estimateCost(req.model, inTok, outTok) },
            };
            return;
          }
        } catch {
          // ignore
        }
      }
    }
  }

  async embed(): Promise<number[][]> {
    // Anthropic has no first-party embeddings endpoint; route embeddings to
    // an OpenAI-compatible provider instead. Surfaced as an explicit error.
    throw new Error('AnthropicProvider does not support embeddings; use an OpenAI-compatible embedding provider.');
  }
}
