import {
  LlmProvider,
  LlmChatRequest,
  LlmChatResult,
  LlmStreamChunk,
  ProviderConfig,
} from '../llm-provider.interface';

/**
 * Implements the OpenAI Chat Completions wire format. Because vLLM, Ollama,
 * LM Studio, Together, Groq and most self-hosted servers expose this exact
 * format, ONE adapter covers both OpenAI and every CUSTOM provider — the only
 * difference is baseUrl + apiKey + model. This is why "Custom Models" needs
 * almost no extra code: point baseUrl at the self-hosted /v1 endpoint.
 */
export class OpenAiCompatProvider implements LlmProvider {
  readonly kind: LlmProvider['kind'];
  private readonly baseUrl: string;
  private readonly apiKey: string;

  // Per-1M-token USD pricing for cost estimation. Unknown models => 0.
  private static readonly PRICING: Record<string, { in: number; out: number }> = {
    'gpt-4o': { in: 2.5, out: 10 },
    'gpt-4o-mini': { in: 0.15, out: 0.6 },
  };

  constructor(config: ProviderConfig) {
    this.kind = config.kind === 'CUSTOM' ? 'CUSTOM' : 'OPENAI';
    this.baseUrl = (config.baseUrl ?? 'https://api.openai.com/v1').replace(/\/$/, '');
    this.apiKey = config.apiKey ?? '';
  }

  private headers(): Record<string, string> {
    const h: Record<string, string> = { 'Content-Type': 'application/json' };
    if (this.apiKey) h['Authorization'] = `Bearer ${this.apiKey}`;
    return h;
  }

  private estimateCost(model: string, promptTokens: number, completionTokens: number): number {
    const p = OpenAiCompatProvider.PRICING[model];
    if (!p) return 0;
    return (promptTokens / 1e6) * p.in + (completionTokens / 1e6) * p.out;
  }

  async chat(req: LlmChatRequest): Promise<LlmChatResult> {
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: this.headers(),
      signal: req.signal,
      body: JSON.stringify({
        model: req.model,
        messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
        temperature: req.temperature ?? 0.7,
        max_tokens: req.maxTokens,
        stream: false,
      }),
    });

    if (!res.ok) {
      throw new Error(`LLM provider error ${res.status}: ${await res.text()}`);
    }

    const data: any = await res.json();
    const promptTokens = data.usage?.prompt_tokens ?? 0;
    const completionTokens = data.usage?.completion_tokens ?? 0;

    return {
      content: data.choices?.[0]?.message?.content ?? '',
      model: data.model ?? req.model,
      usage: {
        promptTokens,
        completionTokens,
        costUsd: this.estimateCost(req.model, promptTokens, completionTokens),
      },
    };
  }

  async *stream(req: LlmChatRequest): AsyncIterable<LlmStreamChunk> {
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: this.headers(),
      signal: req.signal,
      body: JSON.stringify({
        model: req.model,
        messages: req.messages.map((m) => ({ role: m.role, content: m.content })),
        temperature: req.temperature ?? 0.7,
        max_tokens: req.maxTokens,
        stream: true,
        stream_options: { include_usage: true },
      }),
    });

    if (!res.ok || !res.body) {
      throw new Error(`LLM provider error ${res.status}: ${await res.text()}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let promptTokens = 0;
    let completionTokens = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      // SSE frames are separated by double newlines.
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const payload = trimmed.slice(5).trim();
        if (payload === '[DONE]') {
          yield {
            delta: '',
            done: true,
            usage: {
              promptTokens,
              completionTokens,
              costUsd: this.estimateCost(req.model, promptTokens, completionTokens),
            },
          };
          return;
        }
        try {
          const json = JSON.parse(payload);
          if (json.usage) {
            promptTokens = json.usage.prompt_tokens ?? promptTokens;
            completionTokens = json.usage.completion_tokens ?? completionTokens;
          }
          const delta = json.choices?.[0]?.delta?.content;
          if (delta) yield { delta, done: false };
        } catch {
          // Ignore malformed keep-alive frames.
        }
      }
    }
  }

  async embed(input: string[], model: string): Promise<number[][]> {
    const res = await fetch(`${this.baseUrl}/embeddings`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify({ model, input }),
    });
    if (!res.ok) {
      throw new Error(`Embedding error ${res.status}: ${await res.text()}`);
    }
    const data: any = await res.json();
    return (data.data ?? []).map((d: any) => d.embedding as number[]);
  }
}
