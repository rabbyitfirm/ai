/**
 * The single contract every model provider implements. Business logic
 * (chat, agents, RAG) depends only on this interface, never on a concrete
 * vendor SDK — so providers are swappable and tenants can bring their own.
 */

export interface LlmMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  toolCallId?: string;
}

export interface LlmChatRequest {
  model: string;
  messages: LlmMessage[];
  temperature?: number;
  maxTokens?: number;
  /** Abort signal so callers can cancel in-flight streams. */
  signal?: AbortSignal;
}

export interface LlmUsage {
  promptTokens: number;
  completionTokens: number;
  /** Estimated USD cost; 0 when pricing is unknown (e.g. self-hosted). */
  costUsd: number;
}

export interface LlmChatResult {
  content: string;
  usage: LlmUsage;
  model: string;
}

/** A single streamed delta. `done` carries final usage. */
export interface LlmStreamChunk {
  delta: string;
  done: boolean;
  usage?: LlmUsage;
}

export interface LlmProvider {
  readonly kind: 'OPENAI' | 'GEMINI' | 'ANTHROPIC' | 'CUSTOM';
  chat(req: LlmChatRequest): Promise<LlmChatResult>;
  stream(req: LlmChatRequest): AsyncIterable<LlmStreamChunk>;
  embed(input: string[], model: string): Promise<number[][]>;
}

/** Resolved config for instantiating a provider for a given tenant. */
export interface ProviderConfig {
  kind: LlmProvider['kind'];
  baseUrl?: string;
  apiKey?: string;
  defaultModel?: string;
}
