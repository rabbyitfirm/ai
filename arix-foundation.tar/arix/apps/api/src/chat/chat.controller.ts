import { Controller, Post, Body, Res, Req } from '@nestjs/common';
import type { Response, Request } from 'express';
import { ModelRouterService } from '../llm/model-router.service';

interface ChatDto {
  organizationId: string;
  model?: string;
  privacyOnly?: boolean;
  temperature?: number;
  messages: { role: 'system' | 'user' | 'assistant' | 'tool'; content: string }[];
}

/**
 * Minimal chat endpoint that streams tokens to the client over SSE, routing
 * through the ModelRouterService. In production this sits behind the auth +
 * tenancy guards and the organizationId comes from the request context, not
 * the body — shown here inline for a runnable starting point.
 */
@Controller('chat')
export class ChatController {
  constructor(private readonly router: ModelRouterService) {}

  @Post('stream')
  async stream(@Body() dto: ChatDto, @Res() res: Response, @Req() req: Request): Promise<void> {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const controller = new AbortController();
    req.on('close', () => controller.abort());

    try {
      for await (const chunk of this.router.stream(
        { organizationId: dto.organizationId, model: dto.model, privacyOnly: dto.privacyOnly },
        dto.messages,
        { temperature: dto.temperature, signal: controller.signal },
      )) {
        res.write(`data: ${JSON.stringify(chunk)}\n\n`);
      }
      res.write('data: [DONE]\n\n');
    } catch (err) {
      res.write(`event: error\ndata: ${JSON.stringify({ message: (err as Error).message })}\n\n`);
    } finally {
      res.end();
    }
  }
}
