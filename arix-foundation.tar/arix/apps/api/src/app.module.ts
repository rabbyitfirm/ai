import { Module } from '@nestjs/common';
import { LlmModule } from './llm/llm.module';
import { ChatModule } from './chat/chat.module';

@Module({
  imports: [LlmModule, ChatModule],
})
export class AppModule {}
