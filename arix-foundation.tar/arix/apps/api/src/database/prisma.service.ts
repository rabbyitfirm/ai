import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

/**
 * Wraps PrismaClient as an injectable NestJS provider.
 *
 * Multi-tenancy note: tenant scoping is enforced at the service layer by
 * always passing `organizationId` in `where` clauses (see ModelRouterService).
 * For defense-in-depth in production, layer Postgres RLS on top using a
 * per-request `SET app.current_org` and policies — but app-level scoping is
 * the simpler, Prisma-native starting point the SRS calls for.
 */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }
}
