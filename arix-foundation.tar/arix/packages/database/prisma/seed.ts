import {
  PrismaClient,
  GlobalRole,
  WorkspaceRole,
  PlanTier,
  SubscriptionStatus,
  ModelProviderKind,
  AgentType,
} from '@prisma/client';
import { createHash } from 'node:crypto';

const prisma = new PrismaClient();

// NOTE: replace with a real bcrypt/argon2 hash in production.
// The API uses argon2; this placeholder keeps the seed dependency-free.
function devHash(input: string): string {
  return 'dev$' + createHash('sha256').update(input).digest('hex');
}

async function main() {
  console.log('Seeding ARIX.ai…');

  const superAdmin = await prisma.user.upsert({
    where: { email: 'admin@arix.ai' },
    update: {},
    create: {
      email: 'admin@arix.ai',
      name: 'ARIX Super Admin',
      globalRole: GlobalRole.SUPER_ADMIN,
      emailVerified: new Date(),
      passwordHash: devHash('admin12345'),
    },
  });

  const demoUser = await prisma.user.upsert({
    where: { email: 'demo@arix.ai' },
    update: {},
    create: {
      email: 'demo@arix.ai',
      name: 'Demo User',
      emailVerified: new Date(),
      passwordHash: devHash('demo12345'),
    },
  });

  const org = await prisma.organization.upsert({
    where: { slug: 'demo' },
    update: {},
    create: {
      name: 'Demo Workspace',
      slug: 'demo',
      ownerId: demoUser.id,
      members: {
        create: [
          { userId: demoUser.id, role: WorkspaceRole.OWNER },
          { userId: superAdmin.id, role: WorkspaceRole.ADMIN },
        ],
      },
      subscription: {
        create: {
          plan: PlanTier.PRO,
          status: SubscriptionStatus.ACTIVE,
        },
      },
    },
  });

  await prisma.modelProvider.create({
    data: {
      organizationId: org.id,
      kind: ModelProviderKind.OPENAI,
      label: 'OpenAI (platform key)',
      defaultModel: 'gpt-4o-mini',
      enabled: true,
    },
  });

  await prisma.modelProvider.create({
    data: {
      organizationId: org.id,
      kind: ModelProviderKind.CUSTOM,
      label: 'Self-hosted (vLLM)',
      baseUrl: 'http://localhost:8000/v1',
      defaultModel: 'meta-llama/Llama-3.1-8B-Instruct',
      enabled: false,
    },
  });

  const project = await prisma.project.create({
    data: {
      organizationId: org.id,
      name: 'Getting Started',
      description: 'Sample project seeded for local development.',
      tags: ['demo', 'sample'],
    },
  });

  await prisma.agent.create({
    data: {
      organizationId: org.id,
      projectId: project.id,
      name: 'SEO Strategist',
      type: AgentType.SEO,
      instructions:
        'You are an SEO strategist. Produce keyword clusters, content briefs, and on-page optimization advice grounded in the provided knowledge base.',
      model: 'gpt-4o-mini',
      temperature: 0.6,
      toolKeys: ['web_search', 'knowledge_search'],
      knowledgeBaseIds: [],
    },
  });

  console.log('Seed complete.');
  console.log('  Super admin: admin@arix.ai / admin12345');
  console.log('  Demo user:   demo@arix.ai / demo12345');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
